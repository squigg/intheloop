var express = require('express');
var app = express();
var port = process.env.port || 1337
var router = express.Router();
import withMongo from 'services/mongo.js'

app.get('/', function (req, res) {
    res.send('Hello World!');
});


router.route('/transactions/:id/meta')

// create a bear (accessed at POST http://localhost:8080/api/bears)
    .post(function(req, res) {

        res.setHeader('Content-Type', 'application/json');
        withMongo((db) => {
            db.collection('transactionMeta').insertOne(args.meta, function (err, r) {
                res.end(JSON.stringify(r || {}, null, 2));
            });
        });

    })

    .get(function(req, res) {

        res.setHeader('Content-Type', 'application/json');
        withMongo((db) => {
            db.collection('transactionMeta').find({'transaction_id': args.id}).toArray(function (err, data) {
                res.end(JSON.stringify(data || {}, null, 2));
            });
        });

    });

app.use('/api', router);

var server = app.listen(port, function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log('Example app listening at http://%s:%s', host, port);
});

