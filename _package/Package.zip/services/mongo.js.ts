/**
 * Created by squigg on 08/11/16.
 */
const MongoClient = require("mongodb").MongoClient;
const mongoConfig = { url: "localhost", port: "27017", db: "intheloop"};

export function withMongo(callback) {
    let url = "mongodb://" + mongoConfig.url + ":" + mongoConfig.port + "/" + mongoConfig.db;
    MongoClient.connect(url, function (err, db) {
        callback(db);
        db.close();
    });
}
